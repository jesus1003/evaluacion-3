package cl.inacap.evaluacion3;

import com.google.firebase.database.FirebaseDatabase;

import java.text.Collator;

public class MyFirebaseApp extends android.app.Application{
    @Override
    public void onCreate()
    {
        super.onCreate();
        Collator FirebaseDatabase = null;
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
    }

}