package cl.inacap.evaluacion3;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.UUID;

import cl.inacap.evaluacion3.modelo.DatabaseReference;
import cl.inacap.evaluacion3.modelo.FirebaseDatabase;
import cl.inacap.evaluacion3.modelo.Usuarios;


public class MainActivity extends AppCompatActivity {
    private EditText etNombreP, etApellidoP, etCorreoP, etPasswordP;
    private ListView lvPersonas;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private ArrayList<Usuarios> listaUsuarios = new ArrayList<>();
    private ArrayAdapter<Usuarios> UsuariosArrayAdapter;
    private Usuarios UsuariosSeleccionada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etNombreP=(EditText) findViewById(R.id.txt_nombrePersona);
        etApellidoP=(EditText) findViewById(R.id.txt_apellidoPersona);
        etCorreoP=(EditText) findViewById(R.id.txt_correoPersona);
        etPasswordP=(EditText) findViewById(R.id.txt_passwordPersona);
        lvPersonas=(ListView) findViewById(R.id.lv_datosPersonas);

        inicializarFirebase();
        listarDatos();
        lvUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                UsuariosSeleccionada = (Usuarios) adapterView.getItemAtPosition(i);
                etNombreP.setText(UsuariosSeleccionada.getNombre());
                etApellidoP.setText(UsuariosSeleccionada.getApellido());
                etCorreoP.setText(UsuariosSeleccionada.getCorreo());
                etPasswordP.setText(UsuariosSeleccionada.getPassword());
            }
        });
    }

    private void listarDatos() {
        databaseReference.child("Persona").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaUsuarios.clear();
                for(DataSnapshot obj: snapshot.getChildren()) {
                    Usuarios p = obj.getValue(Usuarios.class);
                    listaUsuarios.add(p);
                }
                UsuariosArrayAdapter = new ArrayAdapter<Usuarios>(MainActivity.this,
                        android.R.layout.simple_list_item_1,
                        listaUsuarios);
                lvUsuarios.setAdapter(UsuariosArrayAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void inicializarFirebase() {
        Object FirebaseApp;
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        String nombre=etNombreP.getText().toString();
        String apellido=etApellidoP.getText().toString();
        String correo=etCorreoP.getText().toString();
        String password=etPasswordP.getText().toString();

        switch(item.getItemId())
        {

            case R.id.icon_add:


                if(validacion())
                {
                    Usuarios p= new Usuarios();
                    p.setUid(UUID.randomUUID().toString());
                    p.setNombre(nombre);
                    p.setApellido(apellido);
                    p.setCorreo(correo);
                    p.setPassword(password);

                    databaseReference.child("Persona").child(p.getUid()).setValue(p);
                    limpiar();
                    Toast.makeText(this, "Agregado",Toast.LENGTH_SHORT).show();
                }



                break;
            case R.id.icon_delete:
                Usuarios p= new Usuarios();
                p.setUid(UsuariosSeleccionada.getUid());
                databaseReference.child("Persona").child(p.getUid()).removeValue();
                limpiar();
                Toast.makeText(this, "Eliminado",Toast.LENGTH_SHORT).show();
                break;

            case R.id.icon_save:
                Usuarios per=new Usuarios();
                per.setUid(UsuariosSeleccionada.getUid());
                per.setNombre(nombre);
                per.setApellido(apellido);
                per.setCorreo(correo);
                per.setPassword(password);

                databaseReference.child("Usuarios").child(per.getUid()).setValue(per);
                limpiar();

                Toast.makeText(this,"Actualizado: "+per.getNombre(),Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }


    private boolean validacion()
    {
        if(etNombreP.getText().toString().equals(""))
        {
            etNombreP.setError("Required");
            return false;
        }
        if(etApellidoP.getText().toString().equals(""))
        {
            etApellidoP.setError("Required");
            return false;
        }
        if(etCorreoP.getText().toString().equals(""))
        {
            etCorreoP.setError("Required");
            return false;
        }
        if(etPasswordP.getText().toString().equals(""))
        {
            etPasswordP.setError("Required");
            return false;
        }
        return true;
    }
    private void limpiar()
    {
        etNombreP.setText("");
        etApellidoP.setText("");
        etCorreoP.setText("");
        etPasswordP.setText("");
    }


}
