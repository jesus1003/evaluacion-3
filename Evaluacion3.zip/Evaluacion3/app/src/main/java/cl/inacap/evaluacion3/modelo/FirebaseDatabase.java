package cl.inacap.evaluacion3.modelo;

public class FirebaseDatabase {
}
